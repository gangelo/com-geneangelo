/**
 * Created with JetBrains RubyMine.
 * User: gangelo
 * Date: 1/5/13
 * Time: 11:28 PM
 * To change this template use File | Settings | File Templates.
 */
$(document).ready(function(){});