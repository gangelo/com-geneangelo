/**
 * Created with JetBrains RubyMine.
 * User: gangelo
 * Date: 1/12/13
 * Time: 7:31 PM
 * To change this template use File | Settings | File Templates.
 */
function jumpToTop(){$("html, body").animate({scrollTop:0},100)};