/**
 * Created with JetBrains RubyMine.
 * User: gangelo
 * Date: 4/19/13
 * Time: 6:44 PM
 * To change this template use File | Settings | File Templates.
 */
$(document).ready(function(){$(".section>.experience:even,.section>.education:even").css("background-color","white"),$(".section>.experience:odd,.section>.education:odd").css("background-color","#efefef")});